import KeyMirror from 'keymirror'

export default KeyMirror({
  GET_ALL: null,
  GET_ALL_ERROR: null,
  CREATE: null,
  CREATE_ERROR: null,
  UPDATE_DONE: null,
  UPDATE_DONE_ERROR: null,
  UPDATE_DESCRIPTION: null,
  UPDATE_DESCRIPTION_ERROR: null,
  DELETE: null,
  DELETE_ERROR: null,
  SET_DISPLAY_TYPE: null
})
